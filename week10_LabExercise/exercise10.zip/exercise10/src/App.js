import logo from './logo.svg';
import './App.css';
import React from 'react';
import DataEntry from './components/dataEntry.component';

function App() {
  return (
    <div>
     <DataEntry />
    </div>
  );
}

export default App;
